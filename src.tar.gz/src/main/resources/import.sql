INSERT INTO sandwich(name, amount, productionDate, price, vegetarian, breadColor) VALUES ('Kanapka_z_szynka',5, '2012-01-10',11,false,'jasne')

INSERT INTO seller(firstName, lastName, removed) VALUES ('Marcin', 'Ossowski', false)
